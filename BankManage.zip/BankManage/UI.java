package day16;

import java.util.*;
public class UI {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		BankAccount bank = new BankAccount();
		
		boolean isTrue = true;
		while(isTrue) {
			System.out.println("Enter 1 for create account");
			System.out.println("Enter 2 for widhdraw");
			System.out.println("Enter 3 show Account Details");
			System.out.println("Enter 4 for deposit");
			System.out.println("Enter 5 to exit ");
			int key = sc.nextInt();
			sc.nextLine();
			
			if(key==1) {
				
				System.out.println("Enter the id");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the Name");
				String name = sc.nextLine();
				System.out.println("Enter the Balance");
				double balance = sc.nextDouble();
				System.out.println("Enter the Pin");
				int pin = sc.nextInt();
				
				bank = new BankAccount(id, name, id, balance, pin);
				
			}else if(key ==2) {
				System.out.println("Enter the Pin ");
				int pin = sc.nextInt();
				System.out.println("Enter the amount");
				double amount = sc.nextDouble();
				double existBalance = bank.getBalance();
				double total = existBalance-amount;
				
				bank.setBalance(total, pin);
				
			}else if(key ==3) {
				System.out.println(bank);
			}
			else if(key==4)
			{
				
				
				System.out.println("Enter the amount");
				double amount = sc.nextDouble();
				double existBalance = bank.getBalance();
				double total = existBalance+amount;
				
				bank.setBalance(total, bank.getPin());
			}
			
			else if (key == 5){
				isTrue = false;
				System.out.println("THANK YOU ");
			}
			
			sc.close();
		
		
		}
	}
}



