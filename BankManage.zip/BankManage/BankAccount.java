package day16;

public class BankAccount {
	
	private int id;
	private String name;
	private long phno;
	private double balance;
	private int pin;
	public BankAccount(int id, String name, long phno, double balance, int pin) {
		super();
		this.id = id;
		this.name = name;
		this.phno = phno;
		this.balance = balance;
		this.pin = pin;
	}
	public BankAccount() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhno() {
		return phno;
	}
	public void setPhno(long phno) {
		this.phno = phno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance , int pin ) {
		if (this.pin == pin) {
			this.balance = balance;
		}
		else {
			System.out.println("ENTERD WRONG PIN NUMBER ");
		}
		this.balance = balance;
	}
	public int getPin() {
		return pin;
	}
	@Override
	public String toString() {
		return "BankAccount [id=" + id + ", name=" + name + ", phno=" + phno + ", balance=" + balance + ", pin=" + pin
				+ "]";
	}
	
	
	

}
