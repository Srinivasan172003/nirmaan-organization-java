package libraryMangementSystem;

import java.util.List;
import java.util.Scanner;

class LibraryService {

	Scanner sc = new Scanner(System.in);

	//ADD STUDENT
	public Library addStudent() {

		Library std = new Library();

		System.out.println("Enter the BOOK Id : ");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the BOOK Name :");
		String stdName = sc.nextLine();
		System.out.println("Enter the BOOK  No : ");
		int rollNo = sc.nextInt();
		System.out.println("Enter the your Phone No ");
		long phoneNo = sc.nextLong();
		
		std = new Library(id, stdName, rollNo, phoneNo);
		return std;

	}
	//VIEW STUDENTS

	public void getStudents(List<Library> stds) {
		System.out.println(stds);
		//PRINT LIST EVERY THING
	}

	public Library getStudentById(List<Library> stds) {
		//RETRIVE BY ID
		System.out.println("Enter the BOOK Id for show : ");
		int id = sc.nextInt();
		// FOR EACH 
		for (Library std : stds) {
			if (id == std.getId()) {
				return std;
			}
		}

		return null;
	}

	public List<Library> putStudent(List<Library> libraries) {
		System.out.println("Enter the BOOK Id to Update : ");
		int id = sc.nextInt();
		sc.nextLine();
		
		for(Library std : libraries) {
			if(std.getId()==id) {
				System.out.println("Enter the BOOK Name :");
				String stdName = sc.nextLine();
				System.out.println("Enter the BOOK No : ");
				int rollNo = sc.nextInt();
				System.out.println("Enter the Phone No ");
				long phoneNo = sc.nextLong();
				std.setName(stdName);
				std.setPhoneNo(phoneNo);
				std.setRollNo(rollNo);
				
			}
		}
		
		return libraries;
	}
	
	
	public List<Library> deleteStudent(List<Library> libraries){

		System.out.println("Enter the BOOK Id to delete : ");
		int id = sc.nextInt();

		for (Library std : libraries) {
			if (id == std.getId()) {
				libraries.remove(std);
				return libraries;
			}
		}

		return libraries;
	}
 
}