package library;

import java.util.ArrayList;
import java.util.Scanner;

public class BookServices {
	
	Scanner sc = new Scanner(System.in);
	
	//ADD BOOKS IN LIBRARY 
	public Book addLibrary() {
		
		System.out.println("ENTER A BOOK ID : ");
		int BookId = sc.nextInt();
		sc.nextLine();
		System.out.println("ENTER A BOOK NAME : ");
		String name = sc.nextLine();
		System.out.println("ENTER A BOOK PRICE : ");
		float price = sc.nextFloat();
		sc.nextLine();
		System.out.println("ENTER AUTHOR NAME :");
		String authorName = sc.nextLine();
		
		return new Book(BookId, name, price, authorName);
		
		
	}
	//READ BOOK LIBRARY 
	public void getBook(ArrayList<Book> BookServices) {
		System.out.println(BookServices);
	}
	//READ BOOK LIBRARY BY BOOKID
	
	public Book getBookID( int ID, ArrayList<Book> BookServices) {
		for (Book bk : BookServices) {
			if (bk.getBookID()== ID) {
				return bk;
			}
		}
		return null;
	}
}
