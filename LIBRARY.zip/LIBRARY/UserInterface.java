package library;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		ArrayList<Book> bk = new ArrayList<Book>();
		Scanner sc = new Scanner(System.in);
		BookServices service = new BookServices();
		Book bk1 = new Book();
		while (true) {
			System.out.println(
					"Enter your choice \n 1 for add Employee \n 2 for show Employees \n 3 for search Employee By Id");
			int key = sc.nextInt();

			if (key == 1) {
				bk.add(service.addLibrary());

			} else if (key == 2) {
				service.getBook(bk);
			} else if (key == 3) {
				System.out.println("Enter the Employee Id : ");
				int id = sc.nextInt();
				System.out.println(service.getBookID(id,bk));
			}

		}
		
	}

}
