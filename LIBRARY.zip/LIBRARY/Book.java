package library;

public class Book {
	private int BookID;
	private String name;
	private float price;
	private String authorName;
	public int getBookID() {
		return BookID;
	}
	public void setBookID(int bookID) {
		BookID = bookID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorNmae(String authorNmae) {
		this.authorName = authorNmae;
	}
	
	public Book(int bookID, String name, float price, String authorNmae) {
		super();
		BookID = bookID;
		this.name = name;
		this.price = price;
		this.authorName = authorNmae;
	}
	
	public Book() {
		super();
	}
	@Override
	public String toString() {
		return "Book [BookID=" + BookID + ", name=" + name + ", price=" + price + ", authorNmae=" + authorName + "]";
	}
	
	
	

}
