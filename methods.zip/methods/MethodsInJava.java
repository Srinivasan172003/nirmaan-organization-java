package day10;

import java.util.Scanner;

public class MethodsInJava {
	//class
	String  name ;
	int rollNum ;
	long phoneNum;
	byte num;
	
	void display() {
		System.out.println(name);
		System.out.println(rollNum);
		System.out.println(phoneNum);
		System.out.println(num);
	}
	
	public static void main(String[] args) {
		MethodsInJava emp = new MethodsInJava();
		emp.name = "RAJESH";
		emp.rollNum = 594845;
		emp.phoneNum = 86485316;
		emp.num =58 ;
		emp.display();
		System.out.println("ENTER A NAME : ");
		Scanner input = new Scanner(System.in);
		MethodsInJava emp2 = new MethodsInJava();
		emp2.name = input.nextLine();
		emp2.rollNum = 578984;
		emp2.phoneNum = 456487231;
		emp2.num =15 ;
		emp2.display();
		
		input.close();
		
	}

}
