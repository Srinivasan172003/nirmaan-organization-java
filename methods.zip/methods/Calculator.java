package day10;

public class Calculator {
	void add(int num1 , int num2) {
		System.out.println("Addition :"+ (num1 + num2));
	}
	void sub(int num1 ,int num2) {
		System.out.println("SUBRACTION : "+(num1 - num2));
	}
	void mul(int num1 , int num2) {
		System.out.println("MULTIPLICATION : "+(num1 * num2));
	}
	void div(int num1 ,int num2) {
		System.out.println("DIVISION :"+(num1 / num2));
	}

}
