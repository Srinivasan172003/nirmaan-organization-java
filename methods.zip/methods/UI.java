package day10;

import java.util.Scanner;

public class UI {
		public static void main(String[] args) {
			Calculator cal = new Calculator();
			
			Scanner val = new Scanner(System.in);
			System.out.println("Enter a first number");
			int num1 = val.nextInt();
			System.out.println("Enter a second number");
			int num2 = val.nextInt();
			cal.add(num1, num2);
			cal.sub(num1, num2);
			cal.mul(num1, num2);
			cal.div(num1, num2);
			
			val.close();
		}
}
