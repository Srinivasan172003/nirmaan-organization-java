package day20;

public class NameInterface implements Iname {

	@Override
	public void add(int a, int b) {
		System.out.println(a + b);
		
	}

	@Override
	public void sub(int a, int c) {
		System.out.println(a - c);
		
		
	}
	public static void main(String[] args) {
		NameInterface N = new NameInterface();
		
		N.add(20, 20);
		N.sub(36, 54);
	}

}
