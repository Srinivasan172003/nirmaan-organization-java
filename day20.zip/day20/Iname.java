package day20;

public interface Iname {
	
	 void add(int a,int b);
	 void sub(int a,int c);
	 

	}
