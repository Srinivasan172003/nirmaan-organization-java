package day2;


//final declared in class
//so we cannot extend to any class
final class A{
	//final declared in method
	final void display() {
		System.out.println("Class A");
	}
	
}

public class FinalEx {
	

	
	public static void main(String[] args) {
		//final declared in integer
		final int week = 7;
		A a = new A();
		a.display();
		System.out.println(week);
	
	}

}
