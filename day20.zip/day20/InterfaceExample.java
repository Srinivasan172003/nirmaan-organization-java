package day20;

// Define the Animal interface
interface Animal {
    // Constant
    String CATEGORY = "Living Being";

    // Static method to check if an animal is a mammal
    static boolean isMammal(String animalName) {
        return animalName.equalsIgnoreCase("Dog") ||
               animalName.equalsIgnoreCase("Cat") ||
               animalName.equalsIgnoreCase("Human");
    }

    // Default method to provide a generic sound behavior
    default void speak() {
        System.out.println("Animal is making a sound.");
    }

    // Abstract method to be implemented by classes
    void move();
}

// Implementing the Animal interface in the Dog class
class Dog implements Animal {
    @Override
    public void move() {
        System.out.println("Dog runs on four legs.");
    }

    @Override
    public void speak() {
        System.out.println("Dog barks: Woof! Woof!");
    }
}

// Implementing the Animal interface in the Bird class
class Bird implements Animal {
    @Override
    public void move() {
        System.out.println("Bird flies in the sky.");
    }

    @Override
    public void speak() {
        System.out.println("Bird chirps: Tweet! Tweet!");
    }
}

// Main class to test the implementation
public class InterfaceExample {
    public static void main(String[] args) {
        // Creating objects
        Animal dog = new Dog();
        Animal bird = new Bird();

        // Calling methods
        System.out.println("Category: " + Animal.CATEGORY);
        System.out.println("Is Dog a mammal? " + Animal.isMammal("Dog"));
        System.out.println("Is Bird a mammal? " + Animal.isMammal("Bird"));

        dog.speak();
        dog.move();

        bird.speak();
        bird.move();
    }
}
