package studentManagementSystem;

import java.util.Scanner;
import java.util.TreeSet;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		StudentService stud = new StudentService();
		TreeSet<Student> ts = new TreeSet<Student>();
		while(true) {
			System.out.println("1.ADD STUDENT : \n 2.Get ALL THE STUDENT DETAILS : \n 3.GET ONE STUDENT: \n 4.UPDATE STUDENT");
			int key=sc.nextInt();
			if(key == 1) {
				ts.add(stud.addStudent());
			}
			else if(key == 2) {
				stud.getStudents(ts);
			}
			else if(key == 3) {
				System.out.println(stud.getStudentById(ts));
			}
			else if(key == 4) {
				stud.putStudent(ts);
			}
			else if(key == 5) {
				stud.deleteStudentById(ts);
			}
			else {
				System.out.println("ENTER A CORRECT CODE :");
			}
		}
	}
	
	

}
