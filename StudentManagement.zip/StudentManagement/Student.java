package studentManagementSystem;

import java.util.Objects;

public class Student implements Comparable<Student>{
	
	private int id;
	private int rollno;
	private String sname;
	private float fees;
	//constructors 
	public Student(int id, int rollno, String sname, float fees) {
		super();
		this.id = id;
		this.rollno = rollno;
		this.sname = sname;
		this.fees = fees;
	}
	public Student() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public float getFees() {
		return fees;
	}
	public void setFees(float fees) {
		this.fees = fees;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", rollno=" + rollno + ", sname=" + sname + ", fees=" + fees + "]";
	}
	@Override
	public int compareTo(Student stu) {
		// TODO Auto-generated method stub
		if (this.id < stu.getId()) {
			return -1;
		}
		else if (this.id > stu.getId()) {
			return 1;
		}
		else {
		return 0;
		}
	}
	
	
	

}
