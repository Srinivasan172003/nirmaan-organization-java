package studentManagementSystem;

import java.util.Set;

public interface IstudentService {
	
	//THIS IS FOR ADD A STUDENTS
	public Student addStudent();
	
	//THIS IS FOR PRINTING A STUDENT
	public void getStudents(Set<Student> set);
	
	//THIS IS FOR GET A STUDENT BY ID
	public Student getStudentById(Set<Student> set);
	
	//THIS IS FOR UPDATING A STUDENT BY ID
	public Set<Student> putStudent(Set<Student> set);
	
	//THIS IS FOR DELETING A STUDENT BY ID
	public Set<Student> deleteStudentById(Set<Student> set);

}
