package studentManagementSystem;

import java.util.Scanner;
import java.util.Set;

public class StudentService implements IstudentService {

	Scanner sc = new Scanner(System.in);
	
	@Override
	public Student addStudent() {
	
		Student stu = new Student();
		
		System.out.println("ENTER THE STUDENT ID :");
		int id = sc.nextInt();
		System.out.println("ENTER THE STUDENT ROLL NUMBER : ");
		int rollno = sc.nextInt();
		sc.nextLine();
		System.out.println("ENTER THE STUDENT NAME :");
		String name = sc.nextLine();
		System.out.println("ENTER THE STUDENT FEE AMOUNT :");
	    Float fees = sc.nextFloat();
		
		return stu =  new Student(id, rollno, name, fees);
		
	}

	@Override
	public void getStudents(Set<Student> stu) {
		System.out.println(stu);
			
	}

	@Override
	public Student getStudentById(Set<Student> stu) {
		System.out.println("ENTER THE STUDENT ID TO SHOW DETAILS : ");
		int id = sc.nextInt();
		for(Student stud : stu ) {
			if(id == stud.getId()) {
				return stud;
				
			}
		}
		return null;
	}

	@Override
	public Set<Student> putStudent(Set<Student> set) {
		// TODO Auto-generated method stub
		System.out.println("ENTER THE STUDENT ID TO UPDATE STUDENT : ");
		int id = sc.nextInt();
		sc.nextLine();
		
		for (Student std : set) {
			if(std.getId() == id) {
				System.out.println("ENTER A ROLL NUMBER TO CHANGE :");
				int rollno = sc.nextInt();
				sc.nextLine();
				System.out.println("ENETR A STUDENT NAME TO UPDATE :");
				String name = sc.nextLine();
				System.out.println("ENTER A STUDENT FEES TO UPDATE");
				float fees = sc.nextFloat();
			
		
			std.setRollno(rollno);
			std.setSname(name);
			std.setFees(fees);
			
		}
		}
		return set;
	}

	@Override
	public Set<Student> deleteStudentById(Set<Student> set) {
		System.out.println("ENETR A STUDENT ID TO DELETE :");
		int id = sc.nextInt();
		
		for(Student std : set) {
			if (id == std.getId()) {
				set.remove(std);
				return set;
			}
		}
		return set;
	}

}
