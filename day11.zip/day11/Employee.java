package day11;

public class Employee {
	private String name;
	private int rollNum;
	private double salery;
	private long number;
	
	public void setName(String EmployeeName ) {
		name = EmployeeName;
	}
	public void setRollNum(int EmployeeRollNum ) {
		rollNum = EmployeeRollNum;
	}
	public void setSalery(double EmployeeSalery) {
		salery =EmployeeSalery;
		
	}
	public void setNumber(long EmployeeNumber) {
		number = EmployeeNumber;
	}
	public String getName() {
		return name;
	}
	public int getRollNum() {
		return rollNum;
	}
		
	public double getSalery() {
		return salery;
	}
	public long getNumber() {
		return number;
	}
}
