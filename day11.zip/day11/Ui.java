package day11;

public class Ui {
	public static void main(String[] args) {
		Employee val = new Employee();
		
		//name
		val.setName("kalai");
		//set name declared 
		System.out.println(val.getName());
		//get name decalred
		
		
		//rollNum
		val.setRollNum(4050);
		System.out.println(val.getRollNum());
		
		//SALERY
		val.setSalery(55689.26);	
		System.out.println(val.getSalery());
		
		val.setNumber(9941967);
		System.out.println(val.getNumber());
	}

}
