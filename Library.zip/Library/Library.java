package day13;

public class Library {
	
	private int id ; 
	private String Name ; 
	private float price ; 
	private String author;
	
	
	//empty constructor
	public Library(){
		
	}
	
	public Library(int id, String name, float price, String author) {
		this.id = id;
		this.Name = name;
		this.price = price;
		this.author = author;
		
		
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Library [id=" + id + ", Name=" + Name + ", price=" + price + ", author=" + author + "]";
	}
	

}
