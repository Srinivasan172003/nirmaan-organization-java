package day13;

import java.util.Scanner;
import day13.Library;
public class UiLibrary {
	
	public static void main(String[] args) {
		Library val = new Library();
		
		System.out.println("LIBRARY ADDMINISTRATION SOFTWARE ");
		System.out.println("ENTER VALUE");
		Scanner sc = new Scanner(System.in);
		
		
		
		
		boolean A = true; 
		
		while(A) {
			System.out.println("ENTER 1 TO ADD DETAILS :  "); 
			System.out.println("ENTER 2 TO UPDATE :");
			System.out.println("ENTER 3 TO VIEW : ");
			System.out.println("ENTER 4 TO EXIT :");
			int value = sc.nextInt();
			
			//data to insert ( 1 )
			if(value == 1) {
				System.out.println("ENTER A ID FOR USER IN NUMBERS :  ");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.println("ENTER A NAME FOR USER : ");
				String name = sc.nextLine();
				
				System.out.println("ENTER A PRICE FOR BOOK : ");
				float price = sc.nextFloat();
				sc.nextLine();
				System.out.println("ENTER A AUTHOR NAME :");
				String author = sc.nextLine();
				
				val= new Library(id,name,price ,author);
				System.out.println("BOOK ADDED SUCCCESSFULLY");
								
			}
			else if (value == 2) {
				System.out.println("ENTER WHICH VALUE ARE TO BE CHANGED : ");
				System.out.println("PRESS 1 TO CHANGE BOOK NAME ");
				System.out.println("PRESS 2 TO CHANGE USER NAME ");
				System.out.println("PRESS 3 TO CHANGE PRICE OF BOOK  ");
				System.out.println("PRESS 4 TO CHANGE AUTHOR NAME ");
				int value2 = sc.nextInt();
				sc.nextLine();
					switch(value2) {
						case 1:
							System.out.println("ENTER A BOOK ID TO CHANGE :");
							int id3 = sc.nextInt();
							sc.nextLine();
							val.setId(id3);
							break;
						case 2:
							System.out.println("ENTER USER NAME TO CHANGE :");
							String name3 = sc.nextLine();
							val.setName(name3);
							break;
						case 3:
							System.out.println("ENTER PRICE TO CHANGE :");
							float price3 = sc.nextFloat();
							val.setPrice(price3);
							break;
						case 4:
							System.out.println("ENTER AUTHOR TO CHANGE :");
							String author3 = sc.nextLine();
							val.setAuthor(author3);	
							break ;
					    }
			}
			 else if (value == 3) {
				 System.out.println(val);
				
				}	
			 else if (value == 4) {
				 System.out.println("THANK YOU FOR YOUR INFORMATION : 😂");
				 A = false;
			 }
			
			}

		}
		

	}



//can be used in view if needed
//System.out.println("ENTER WHICH VALUE TO BE SHOW :");
//System.out.println("ENTER 1 TO SHOW ID : ");
//System.out.println("ENTER 2 TO SHOW NAME :");
//System.out.println("ENTER 3 TO SHOW PRICE :");
//System.out.println("ENTER 4 TO SHOW AUTHOR ");
//System.out.println("ENTER 5 TO VIEW ALL DATA :");
//int value3 = sc.nextInt();
//	switch(value3) {
//		case 1 :
//			System.out.println("NAME OF THE ID :");
//			System.out.println(val.getName());
//			break;
//		case 2:
//			System.out.println("NAME OF THE BOOK:");
//			System.out.println(val.getName());
//			break;
//		case 3:
//			System.out.println("PRICE OF THE BOOK :");
//			System.out.println(val.getPrice());
//			break;
//		case 4:
//			System.out.println("AUTHOR OF THE BOOK :");
//			System.out.println(val.getAuthor());
//			break;
//		case 5:
//			System.out.println("ALL DETAILS : ");
//			System.out.println(val.getId() +  val.getName() + val.getPrice() + val.getAuthor());
//			break;
//	}
//	

